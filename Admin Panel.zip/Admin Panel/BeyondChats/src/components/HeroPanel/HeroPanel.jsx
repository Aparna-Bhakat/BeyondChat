import { motion } from "framer-motion";
import ChatPanel from "../ChatPanel/ChatPanel";

const statsData = [
  {
    title: "5 Notifications",
    description: "Check your latest messages",
    bg: "bg-[#e6f4f7]",
  },
  {
    title: "50 Happy Customers",
    description: "Every customer is satisfied 🎉",
    bg: "bg-[#dff1f5]",
  },
  {
    title: "⭐ 4.5 Average Rating",
    description: "Keep up the amazing service!",
    bg: "bg-[#e3f0f7]",
  },
];

const HeroPanel = () => {
  return (
    <main className="pt-16 pl-6  lg:pl-0">
      <motion.div
        className="pt-6 lg:ml-64 px-4 sm:px-6 lg:px-12 max-w-7xl mx-auto min-h-screen bg-[#f7fafc]"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <motion.h1
          className="text-xl sm:text-2xl lg:text-4xl font-bold text-[#245970] mb-6"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          Hi Aparna
        </motion.h1>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          initial="hidden"
          animate="visible"
          variants={{
            visible: { transition: { staggerChildren: 0.2 } },
          }}
        >
          {statsData.map((item, index) => (
            <motion.div
              key={index}
              className={`${item.bg} p-6 rounded-xl shadow-md hover:shadow-xl transition duration-300 flex flex-col justify-center`}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
              }}
            >
              <p className="text-base sm:text-lg font-semibold text-[#245970]">{item.title}</p>
              <p className="text-xs sm:text-sm text-gray-600">{item.description}</p>
            </motion.div>
          ))}
        </motion.div>


    {/* ChatPanel */}

                 <ChatPanel/>

      </motion.div>

      
    </main>
  );
};

export default HeroPanel;
