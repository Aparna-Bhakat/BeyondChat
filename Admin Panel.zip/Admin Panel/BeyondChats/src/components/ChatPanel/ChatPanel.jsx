import Chats from "../../DummyData/CustomerSupportsData";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const ChatPanel = () => {
  return (
    <div className="w-full p-6">
      <h1 className="text-2xl font-bold mb-6 text-center text-[#245970]">Customer Support Chats</h1>
      <div className="grid gap-4">
        {Chats.map((chat, index) => {
          const isEven = index % 2 === 0;

          return (
            <motion.div
              key={index}
              className="flex items-center bg-white shadow-md rounded-xl p-4 w-full "
              initial={{ opacity: 0, x: isEven ? -40 : 40, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.5, ease: 'easeOut' }}
            >
              <img
                src={chat.user.avatar}
                alt={chat.user.name}
                className="w-14 h-14 rounded-full mr-4 border-2 border-[#4f8ea9]"
              />
              <div className="flex-1">
                <h2 className="font-semibold text-sm lg:text-lg text-[#245970]">{chat.user.name}</h2>
                <p className="text-gray-600 hidden md:block lg:block">{chat.user.issue}</p>
              </div>
              <Link to={`/chat/${chat.user.name}`}>
                <button className="bg-[#4f8ea9] text-white px-4 py-2 rounded-md hover:bg-[#3b6d83] transition">
                  View Chat
                </button>
              </Link>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default ChatPanel;
