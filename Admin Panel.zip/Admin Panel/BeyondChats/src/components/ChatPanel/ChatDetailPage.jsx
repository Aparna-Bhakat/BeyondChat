import { useParams } from "react-router-dom";
import { useState } from "react";
import Chats from "../../DummyData/CustomerSupportsData";
import AIAssistant from "./AIAssistant";

const ChatDetailPage = () => {
  const { userName } = useParams();
  const chat = Chats.find((c) => c.user.name === userName);

  const [aiMessages, setAiMessages] = useState([
    { sender: "ai", message: "Hi! I'm here to help. What can I assist with?" }
  ]);

  if (!chat) return <div className="p-6 text-red-500">Chat not found!</div>;

  return (
    <div className="flex  flex-col md:flex-row h-auto w-full lg:h-screen ">
      {/* Main Chat Section */}
      <div className="flex-1 flex flex-col bg-[#f1f5f9] ">
        <div className="p-4 md:p-6 border-b bg-white">
          <h2 className="text-xl md:text-2xl font-bold text-[#245970] mb-2">
            {chat.user.name}'s Chat
          </h2>
          <div className="flex items-center flex-wrap gap-4">
            <img
              src={chat.user.avatar}
              alt={chat.user.name}
              className="w-12 h-12 md:w-14 md:h-14 rounded-full border-2 border-[#4f8ea9]"
            />
            <div>
              <p className="text-[#245970] font-semibold">{chat.user.name}</p>
              <p className="text-gray-600 text-sm">{chat.user.issue}</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
          {chat.conversation.map((msg, index) => (
            <div
              key={index}
              className={`p-3 rounded-md max-w-[85%] md:max-w-[75%] ${
                msg.sender === "user"
                  ? "bg-gray-300 self-start"
                  : "bg-[#e1f5fe] self-end ml-auto"
              }`}
            >
              <p className="text-sm">{msg.message}</p>
            </div>
          ))}
        </div>

        <div className="w-full flex flex-col sm:flex-row items-center gap-2 px-4 py-3 bg-white border-t">
          <input
            className="h-11 px-4 border border-gray-300 rounded-lg bg-[#e1f5fe] text-sm focus:outline-none focus:ring-2 focus:ring-[#245970] transition-all duration-200 w-full w-min[300px]"
            placeholder="Type your message..."
          />
          <button
            className="h-11 w-full sm:w-auto px-6 bg-[#245970] hover:bg-[#1b4560] text-white text-sm font-medium rounded-lg shadow-md transition-all duration-200"
          >
            SEND
          </button>
        </div>
      </div>

      {/* Right Sidebar */}
      <div className="w-3/4 md:w-2/3 lg:w-1/4 bg-white border-t md:border-t-0 md:border-l p-4 overflow-y-auto flex flex-col">
        <div>
          <h2 className="text-lg font-bold text-[#245970] mb-4">Check Status</h2>
          <ul className="space-y-3 text-sm">
            <li className="bg-green-50 p-2 rounded cursor-pointer hover:bg-green-100">📦 Track my order</li>
            <li className="bg-green-50 p-2 rounded cursor-pointer hover:bg-green-100">💸 Refund status</li>
            <li className="bg-green-50 p-2 rounded cursor-pointer hover:bg-green-100">🔁 Return process</li>
          </ul>
        </div>

        {/* AI Assistant */}
        <div className="mt-6 md:mt-auto">
          <AIAssistant aiMessages={aiMessages} setAiMessages={setAiMessages} />
        </div>
      </div>
    </div>
  );
};

export default ChatDetailPage;
