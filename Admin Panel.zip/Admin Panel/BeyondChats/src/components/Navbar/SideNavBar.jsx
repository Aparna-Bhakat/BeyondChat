import { Link, useLocation } from "react-router-dom";
import {
  FaHome,
  FaUserFriends,
  FaComments,
  FaRobot,
  FaCog,
} from "react-icons/fa";

const sidebarLinks = [
  { name: "Home", path: "/", icon: <FaHome /> },
  { name: "Users", path: "/users", icon: <FaUserFriends /> },
  { name: "AI Assistant", path: "/ai", icon: <FaRobot /> },
  { name: "Settings", path: "/settings", icon: <FaCog /> },
];

const Sidebar = () => {
  const location = useLocation();

  return (
    <aside className=" fixed top-16 left-0 h-screen lg:w-64 bg-gradient-to-b from-[#4f8ea9] to-[#245970] text-white z-40 pt-11">

      <nav className="flex flex-col gap-4">
        {sidebarLinks.map(({ name, path, icon }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={name}
              to={path}
              className={`flex items-center lg:gap-4 justify-center lg:justify-start px-2 py-3 rounded-md font-semibold transition-all duration-300
                ${
                  isActive
                    ? "bg-white text-[#245970]"
                    : "hover:bg-white hover:text-[#245970]"
                }`}
            >
              <span className="text-xl">{icon}</span>
              <span className="hidden lg:inline text-md">{name}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
};

export default Sidebar;
