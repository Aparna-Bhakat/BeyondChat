const Chats = [
  {
    user: {
      name: "Aanya Patel",
      avatar: "https://randomuser.me/api/portraits/women/12.jpg",
      issue: "Lipstick shade doesn't match my skin tone.",
    },
    conversation: [
      { sender: "user", message: "Hey, the lipstick I ordered looks too pale on me." },
      { sender: "expert", message: "Hi Aanya! Sorry to hear that. Can you share the shade name?" },
      { sender: "user", message: "Yes, it's Coral Crush #23." },
      { sender: "expert", message: "Got it! That’s best for light skin tones. We can help you exchange it with a warmer shade." },
      { sender: "user", message: "That’d be amazing. Thanks!" },
      { sender: "expert", message: "Sending you shade suggestions now. ❤️" },
    ],
  },
  {
    user: {
      name: "Emily Thompson",
      avatar: "https://randomuser.me/api/portraits/women/45.jpg",
      issue: "Order payment failed but amount deducted.",
    },
    conversation: [
      { sender: "user", message: "I tried placing my order but payment failed. Money got deducted though." },
      { sender: "expert", message: "Hi Emily! So sorry. Could you share the last 4 digits of your payment ID?" },
      { sender: "user", message: "It's 7834." },
      { sender: "expert", message: "Thanks! I’ve raised this to our finance team. You’ll get a refund or confirmation in 2 hrs." },
      { sender: "user", message: "Alright, waiting. Please notify me soon." },
      { sender: "expert", message: "Absolutely, we'll update you via email as well. 🙏" },
    ],
  },
  {
    user: {
      name: "Ritika Verma",
      avatar: "https://randomuser.me/api/portraits/women/18.jpg",
      issue: "My moisturizer bottle came broken.",
    },
    conversation: [
      { sender: "user", message: "I opened my parcel today and the moisturizer bottle is cracked." },
      { sender: "expert", message: "Oh no! Can you please send us a photo of the item and the packaging?" },
      { sender: "user", message: "Sure, sending it now." },
      { sender: "expert", message: "Received! We’ll ship a replacement free of cost within 2 days." },
      { sender: "user", message: "Thank you so much!" },
      { sender: "expert", message: "You’re most welcome 💖" },
    ],
  },
  {
    user: {
      name: "Sofia Sharma",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
      issue: "My order is delayed. No updates.",
    },
    conversation: [
      { sender: "user", message: "Placed my order a week ago. Still no update!" },
      { sender: "expert", message: "Hi Sofia, sorry about this! Can you share your order ID?" },
      { sender: "user", message: "#CB456789" },
      { sender: "expert", message: "Courier tried delivery but couldn’t reach you. We’ve rescheduled for today." },
      { sender: "user", message: "Okay, please make sure it comes today." },
      { sender: "expert", message: "Yes, before 6 PM today with SMS tracking." },
    ],
  },
  {
    user: {
      name: "Jacob Müller",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      issue: "Eye shadow melted in the parcel.",
    },
    conversation: [
      { sender: "user", message: "My eyeshadow melted in the parcel, it's unusable!" },
      { sender: "expert", message: "Oh no Jacob! Can you send us a picture of the damage?" },
      { sender: "user", message: "Sure, uploading now." },
      { sender: "expert", message: "Thanks. We’ll issue a replacement and report this to our courier team." },
      { sender: "user", message: "Appreciate it." },
      { sender: "expert", message: "We care about your experience 🌸" },
    ],
  },
  {
    user: {
      name: "Mira Das",
      avatar: "https://randomuser.me/api/portraits/women/5.jpg",
      issue: "Foundation too dry for my skin.",
    },
    conversation: [
      { sender: "user", message: "The foundation I got feels dry and cakey." },
      { sender: "expert", message: "Hi Mira, may I know your skin type?" },
      { sender: "user", message: "Dry to combination." },
      { sender: "expert", message: "You might need our DewDrop Hydrating Foundation. We’ll help you switch!" },
      { sender: "user", message: "That sounds better. Please guide me." },
      { sender: "expert", message: "Done! You’ll receive a replacement link in 5 mins." },
    ],
  },
  {
    user: {
      name: "Liam Scott",
      avatar: "https://randomuser.me/api/portraits/men/47.jpg",
      issue: "Product received is different from what I ordered.",
    },
    conversation: [
      { sender: "user", message: "I ordered a peach lip balm, got a strawberry one instead!" },
      { sender: "expert", message: "So sorry Liam. Can you upload a photo of what you received?" },
      { sender: "user", message: "Yes, done." },
      { sender: "expert", message: "Thanks. We’re sending you the correct item. Keep the wrong one as a gift 🎁" },
      { sender: "user", message: "Wow, that’s really sweet!" },
      { sender: "expert", message: "We’re always here for you! 💄" },
    ],
  },
  {
    user: {
      name: "Zara Khan",
      avatar: "https://randomuser.me/api/portraits/women/60.jpg",
      issue: "AI assistant gave wrong shade suggestions.",
    },
    conversation: [
      { sender: "user", message: "The AI suggested a very dark shade. It doesn't suit me." },
      { sender: "expert", message: "Hi Zara! Sorry about that. Can I know your natural undertone?" },
      { sender: "user", message: "Cool undertone, fair skin." },
      { sender: "expert", message: "Thanks! Let me update your profile. Here are better matches: Pink Blush 21 & Rose Dew 14." },
      { sender: "user", message: "These look good. Much better!" },
      { sender: "expert", message: "Awesome! Let us know if you want to try them virtually 💕" },
    ],
  },
];

export  default Chats