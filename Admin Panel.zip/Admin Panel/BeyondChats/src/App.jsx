import { createBrowserRouter, RouterProvider } from "react-router-dom";
import './App.css'
import Homepage from "./components/Homepage/Homepage";
import ChatDetailPage from "./components/ChatPanel/ChatDetailPage";
import ChatPanel from "./components/ChatPanel/ChatPanel";
import AIAssistant from "./components/ChatPanel/AIAssistant";


const  router =createBrowserRouter([
  {

  path:"/",
  element:<Homepage/>
  },
  {path:"/chat/:userName",
  element:<ChatDetailPage/>},
  

  {path:"/users",
  element:<ChatPanel/>
  },

  {
    path:"/ai",
    element:<AIAssistant/>
  }


])

function App(){
  return(
      <div>
    
      <RouterProvider router={router}/>
     

    </div>
  )
}


export default App
